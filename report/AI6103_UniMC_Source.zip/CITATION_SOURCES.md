# Citation audit and sources

The twelve DBLP-indexed records were taken from DBLP's standard BibTeX export view. Their original exports are in `source/citation_exports/`. The manuscript uses the normalized `source/references.bib`, with stable local keys, concise proceedings names, protected acronym casing, and official paper links or DOIs. DBLP-specific machine metadata is retained only in the originals. The official AAAI 2024 style generates the author–year citations and reference layout.

| Manuscript key | Bibliographic source |
| --- | --- |
| yang2022unimc | [DBLP: UniMC, EMNLP 2022](https://dblp.org/rec/conf/emnlp/YangWGZZWGZS22.html?view=bibtex) |
| lan2020albert | [DBLP: ALBERT, ICLR 2020](https://dblp.org/rec/conf/iclr/LanCGGSS20.html?view=bibtex) |
| hu2022lora | [DBLP: LoRA, ICLR 2022](https://dblp.org/rec/conf/iclr/HuSWALWWC22.html?view=bibtex), published conference record |
| guo2017calibration | [DBLP: temperature scaling, ICML 2017](https://dblp.org/rec/conf/icml/GuoPSW17.html?view=bibtex), published conference record |
| bisk2020piqa | [DBLP: PIQA, AAAI 2020](https://dblp.org/rec/conf/aaai/BiskZLGC20.html?view=bibtex); surname Le Bras kept together for BibTeX |
| talmor2019commonsenseqa | [DBLP: CommonsenseQA, NAACL 2019](https://dblp.org/rec/conf/naacl/TalmorHLB19.html?view=bibtex) |
| clark2018arc | [DBLP: ARC, CoRR 2018](https://dblp.org/rec/journals/corr/abs-1803-05457.html?view=bibtex), formatted as arXiv:1803.05457 using the AAAI preprint example |
| mihaylov2018openbookqa | [DBLP: OpenBookQA, EMNLP 2018](https://dblp.org/rec/conf/emnlp/MihaylovCKS18.html?view=bibtex) |
| socher2013sst | [DBLP: SST, EMNLP 2013](https://dblp.org/rec/conf/emnlp/SocherPWCMNP13.html?view=bibtex), initials verified against the [published PDF](https://aclanthology.org/D13-1170.pdf) |
| demarneffe2019commitmentbank | [Original publisher](https://ojs.ub.uni-konstanz.de/sub/index.php/sub/article/view/601), vol. 23, no. 2, pp. 107–124. No matching DBLP record was found for this specific original dataset paper. |
| roemmele2011copa | [DBLP: COPA, AAAI Spring Symposium 2011](https://dblp.org/rec/conf/aaaiss/RoemmeleBG11.html?view=bibtex); DBLP lists Technical Report SS-11-06 and no pagination |
| zellers2019hellaswag | [DBLP: HellaSwag, ACL 2019](https://dblp.org/rec/conf/acl/ZellersHBFC19.html?view=bibtex) |
| wang2019superglue | [DBLP: SuperGLUE, NeurIPS 2019](https://dblp.org/rec/conf/nips/WangPNSMHLB19.html?view=bibtex), vol. 32, pp. 3261–3275 |

Audit: 14 in-text citation uses, 13 unique keys, and 13 matching rendered references; no missing or unused entries. Dataset citations identify the original datasets and benchmark; sample counts come from the project's recorded evaluation, not from these bibliography entries.
