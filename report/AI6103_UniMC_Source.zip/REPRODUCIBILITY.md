# Experiment records

Source: [group repository at c7964fd](https://github.com/Yuxiang5555/AI6103-group-project/tree/c7964fd819274722f02885d90d9ad1a0ffe05281). Paths below are relative to that snapshot.

## Two-source decision heads and LoRA

- Checkpoint: `IDEA-CCNL/Erlangshen-UniMC-Albert-235M-English` at `e3aeebc7bd475d559bd0cbd8d17abf4e159d1260`. The recorded backbone, configuration, tokenizer and encoding fingerprints are in `unimc_model_optimization/models/manifest.json` and `unimc_model_optimization/results/base_model_signature.json`. The backbone weights are separate from the released small trained modules.
- Length and precision: 512 tokens, with option truncation permitted by the encoder. Cached head features come from FP32 extraction (raw states stored in FP16, predecoder features stored in FP32). LoRA trains in BF16, evaluates in FP32 and uses the same length limit. See `aggregate_eval/run_targets.py` and `unimc_model_optimization/results/lora/training_config.json`.
- Data: `unimc_model_optimization/prepare_pilot_data.py` and `unimc_model_optimization/prepare_data.py` document the source preparation: reject duplicate candidate strings, exclude exact matches to official development data from the training pool, deduplicate questions and subsample the source training data. `aggregate_eval/target_manifest.json` pins the target data revisions and records retention of all rows; `aggregate_eval/prepare_targets.py` defines the question templates and modifications.
- Versions recorded in the base-model signature: Python 3.10.22, PyTorch 2.5.1, CUDA runtime 12.4, Transformers 4.20.1, SentencePiece 0.1.99 and NumPy 1.26.4. The base-model record provides encoding hashes instead of an upstream Fengshenbang-LM Git commit.

## Four-source decision heads and calibration

- The recipe in `unimc_decision_layers/run_all.sh` uses the official English UniMC checkpoint by default, with a default 512-token limit in `unimc_decision_layers/extract_features.py`. The archived extraction log confirms CUDA and BF16. The exact checkpoint revision and any length override are unrecorded in that log, so the recipe defaults are kept separate from the run-verified two-source settings.
- Hardware and versions as reported in `unimc_decision_layers/RESULTS_2026-11-18.md`: NVIDIA A40, PyTorch 2.8, CUDA 13.2. See `unimc_decision_layers/data/splits.json` and `unimc_decision_layers/prepare_data.py` for the seeded 80/10/10 training split, separate public validation sets and dataset-specific templates. The two-source and four-source target templates and SST-2 dataset sources differ.
- Temperature scaling starts from the archived four-source logits. Its provenance is in `calibration/input_manifest.json` and `calibration/results/report.md`.

## LoRA loss aggregation

The selected-checkpoint comparison in the Discussion uses the per-dataset NLLs in `unimc_model_optimization/results/lora/training_summary.json`. The reported task-macro NLL averages CommonsenseQA and PIQA equally. The separate question-weighted NLL weights the same two values by 598 and 919, respectively, then divides by 1,517. This recomputation uses stored losses; it neither refits nor reevaluates the model.
