import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.size':9,'pdf.fonttype':42})
fig, axes=plt.subplots(2,1,figsize=(3.35,2.5),gridspec_kw={'height_ratios':[1,1.3]})
for ax, labels, vals, lows, highs in [
 (axes[0],['Original'],[-.862956],[-2.218839],[.051905]),
 (axes[1],['Centered self-only','Centered MLP'],[.017079,.019140],[-.034024,-.023236],[.083546,.074793])]:
 ys=list(range(len(vals)))
 ax.errorbar(vals,ys,xerr=[[v-l for v,l in zip(vals,lows)],[h-v for v,h in zip(vals,highs)]],fmt='o',color='#245b7a',capsize=3,markersize=4)
 ax.axvline(0,color='#777777',linestyle='--',linewidth=.8)
 ax.set_yticks(ys,labels)
 ax.set_ylim(-.6,len(vals)-.4)
 ax.spines[['top','right']].set_visible(False)
 ax.grid(axis='x',alpha=.15)
axes[0].set_xlim(-2.4,.3)
axes[1].set_xlim(-.05,.10)
axes[1].set_xlabel('Accuracy difference (pp)')
fig.tight_layout(pad=.5,h_pad=1)
fig.savefig('figures/paired_differences.pdf',bbox_inches='tight')
fig.savefig('figures/paired_differences.png',dpi=220,bbox_inches='tight')

# New panels derived from saved question/seed changes and calibration tables.
import csv, json
from pathlib import Path
from collections import Counter
import numpy as np
from matplotlib.colors import TwoSlopeNorm
data=Path('analysis_data')
rows=list(csv.DictReader((data/'changed.csv').open()))
assert len({(r['task'],r['model'],r['id']) for r in rows})==len(rows)
metrics=json.loads((data/'metrics.json').read_text())['per_task']
tasks=['sst2','cb','copa','hellaswag']
labels=['SST-2','CB','COPA','HellaSwag']
summary={}
for task in tasks:
    d=[r for r in rows if r['task']==task and r['model'].startswith('centered_full_seed')]
    sizes=metrics[task]['baseline']['original']; n=sizes['n']
    summary[task]=Counter(changed=len(d), corrected=sum(int(r['corrected']) for r in d), harmed=sum(int(r['harmed']) for r in d))
    c,h=summary[task]['corrected'],summary[task]['harmed']
    for seed in (42,43,44):
        name=f'centered_full_seed{seed}'
        diff=round(n*(metrics[task][name]['original']['accuracy']-sizes['accuracy']))
        assert diff==sum(int(r['corrected'])-int(r['harmed']) for r in d if r['model']==name)
    summary[task]['contribution_pp']=100*(c-h)/(3*n*4)
vals=[summary[t]['contribution_pp'] for t in tasks]
fig, ax=plt.subplots(figsize=(3.35,1.85))
y=list(range(len(tasks)))
ax.barh(y,vals,color=['#26786b' if v>=0 else '#9e3f25' for v in vals],height=.52)
ax.set_yticks(y,labels)
ax.invert_yaxis()
ax.set_xlim(-1.03,.28)
ax.set_xticks([-1,-.75,-.50,-.25,0])
ax.axvline(0,color='#666',lw=.7)
ax.set_xlabel('Contribution to macro difference (pp)')
ax.spines[['top','right','left']].set_visible(False)
for yi,v in enumerate(vals):
    ax.annotate(f'{v:+.3f}' if v else '0.000',(v,yi),xytext=(5,0),textcoords='offset points',va='center',ha='left',fontsize=8,color='white' if v<-.1 else '#222')
fig.tight_layout(pad=.4)
fig.savefig('figures/macro_contributions.pdf',bbox_inches='tight')

models={'unimc':'UniMC','mlp':'MLP','tf_noint':'Self-only','tf_int':'Full','tf_gate':'Gated'}
with (data/'calibration_per_dataset_summary.csv').open(newline='') as f:
    nll={(r['model'],r['dataset'],r['stage']):float(r['nll_mean'])
         for r in csv.DictReader(f) if r['split']=='test' and r['dataset'] in tasks and r['model'] in models}
a=np.array([[nll[m,t,'after']-nll[m,t,'before'] for t in tasks] for m in models])
fig, ax=plt.subplots(figsize=(3.35,1.88))
im=ax.imshow(a,cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-.056,vcenter=0,vmax=.056),aspect='auto')
ax.set_xticks(range(4),labels)
ax.set_yticks(range(5),list(models.values()))
ax.tick_params(length=0)
for i,j in np.ndindex(a.shape):
    ax.text(j,i,f'{a[i,j]:+.4f}',ha='center',va='center',fontsize=7.5,color='white' if abs(a[i,j])>.034 else '#161616')
for s in ax.spines.values(): s.set_visible(False)
ax.set_title('Change in NLL (after − before)',fontsize=9)
fig.tight_layout(pad=.45)
fig.savefig('figures/calibration_nll.pdf',bbox_inches='tight')
print(json.dumps(summary,indent=2))
