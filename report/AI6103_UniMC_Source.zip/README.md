# AI6103 UniMC paper draft with audited references

- **Read:** AI6103_UniMC_Draft.pdf.
- **Edit:** source/main.tex and source/references.bib. Page one lists all six names, matriculation numbers, and NTU email addresses.
- **Method overview:** source/figures/method_overview.svg is the editable vector original; source/figures/method_overview.pdf is the companion vector PDF placed in the paper. No SVG conversion or shell escape is needed to compile.
- **Build:** with a regular TeX Live installation and latexmk, run `cd source && ./build.sh`. The output is build/main.pdf. To regenerate the three quantitative figures, run `python make_figure.py` in source/ with Matplotlib and NumPy installed.
- **Format:** official AAAI 2024 style and bibliography style unchanged, from https://aaai.org/authorkit24-2/. The PDF is six pages total.
- **Evidence:** Yuxiang5555/AI6103-group-project, commit c7964fd819274722f02885d90d9ad1a0ffe05281. Quantitative figure inputs are in source/analysis_data/. The script checks that question-level correction counts reconcile with the per-task accuracy changes.

This revision integrates the method overview, distinguishes the two head experiments in a compact comparison table, and foregrounds the matched full-attention versus self-only comparison. It retains the prior accuracy-change and calibration analysis. No model was retrained, no original sources were overwritten, and nothing was submitted.

The prose revision clarifies how the three methods relate to UniMC, distinguishes the reported observations from possible explanations, and corrects the description of the LoRA gradient comparison. The calibration discussion includes a descriptive recomputation from the pinned `calibration/results/per_dataset_summary.csv` (included as `source/analysis_data/calibration_per_dataset_summary.csv`). The recomputation averages the four `unimc` calibration rows per stage with equal weights and compares them with the example-weighted average (112, 974, 496 and 1,611 examples for ARC-Challenge, CommonsenseQA, OpenBookQA and PIQA). No model or temperature was fitted again.

Implementation records and source locations: see REPRODUCIBILITY.md. Citation provenance and audit: see CITATION_SOURCES.md.
